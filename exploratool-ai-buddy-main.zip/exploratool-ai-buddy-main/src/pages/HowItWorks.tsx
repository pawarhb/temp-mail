
import Header from "@/components/Header";
import { Card } from "@/components/ui/card";
import { Mail, Clock, Shield, Zap, CheckCircle, ArrowRight } from "lucide-react";
import AdSpace from "@/components/AdSpace";

const HowItWorks = () => {
  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <main className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="text-center mb-12">
          <Mail className="h-16 w-16 text-blue-600 mx-auto mb-6" />
          <h1 className="text-4xl font-bold text-gray-900 mb-4">How It Works</h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Generate temporary emails in seconds and protect your privacy with our AI-powered service
          </p>
        </div>

        {/* Ad Space */}
        <div className="mb-12">
          <AdSpace size="rectangle" className="mx-auto max-w-sm" />
        </div>

        {/* Steps Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-16">
          <Card className="p-6 text-center bg-white">
            <div className="bg-blue-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
              <span className="text-2xl font-bold text-blue-600">1</span>
            </div>
            <h3 className="font-semibold text-gray-900 mb-2">Generate Email</h3>
            <p className="text-sm text-gray-600">Click "Generate Email" to instantly create a temporary email address</p>
          </Card>

          <Card className="p-6 text-center bg-white">
            <div className="bg-green-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
              <span className="text-2xl font-bold text-green-600">2</span>
            </div>
            <h3 className="font-semibold text-gray-900 mb-2">Use Anywhere</h3>
            <p className="text-sm text-gray-600">Copy your temporary email and use it for signups, downloads, or verification</p>
          </Card>

          <Card className="p-6 text-center bg-white">
            <div className="bg-purple-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
              <span className="text-2xl font-bold text-purple-600">3</span>
            </div>
            <h3 className="font-semibold text-gray-900 mb-2">Receive Emails</h3>
            <p className="text-sm text-gray-600">Check your inbox to receive emails with auto-refresh functionality</p>
          </Card>

          <Card className="p-6 text-center bg-white">
            <div className="bg-orange-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
              <span className="text-2xl font-bold text-orange-600">4</span>
            </div>
            <h3 className="font-semibold text-gray-900 mb-2">Auto-Delete</h3>
            <p className="text-sm text-gray-600">Emails automatically delete after 24 hours for your privacy</p>
          </Card>
        </div>

        {/* Features Section */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-16">
          <div className="lg:col-span-2 space-y-8">
            <Card className="p-8 bg-white">
              <div className="flex items-center space-x-4 mb-6">
                <Shield className="h-8 w-8 text-blue-600" />
                <h2 className="text-2xl font-bold text-gray-900">Privacy Guaranteed</h2>
              </div>
              <div className="space-y-4 text-gray-700">
                <p>Your privacy is our top priority. We never store personal information and all emails are automatically deleted after 24 hours.</p>
                <ul className="space-y-2">
                  <li className="flex items-center"><CheckCircle className="h-5 w-5 text-green-500 mr-2" />No registration required</li>
                  <li className="flex items-center"><CheckCircle className="h-5 w-5 text-green-500 mr-2" />24-hour auto-deletion</li>
                  <li className="flex items-center"><CheckCircle className="h-5 w-5 text-green-500 mr-2" />No personal data collection</li>
                  <li className="flex items-center"><CheckCircle className="h-5 w-5 text-green-500 mr-2" />SSL encryption</li>
                </ul>
              </div>
            </Card>

            <Card className="p-8 bg-white">
              <div className="flex items-center space-x-4 mb-6">
                <Zap className="h-8 w-8 text-blue-600" />
                <h2 className="text-2xl font-bold text-gray-900">AI-Powered Features</h2>
              </div>
              <div className="space-y-4 text-gray-700">
                <p>Our advanced AI system enhances your experience with smart spam filtering and intelligent suggestions.</p>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="flex items-start space-x-3">
                    <ArrowRight className="h-5 w-5 text-blue-600 mt-0.5" />
                    <div>
                      <h4 className="font-semibold">Smart Spam Detection</h4>
                      <p className="text-sm">AI filters out unwanted emails automatically</p>
                    </div>
                  </div>
                  <div className="flex items-start space-x-3">
                    <ArrowRight className="h-5 w-5 text-blue-600 mt-0.5" />
                    <div>
                      <h4 className="font-semibold">Auto-Refresh Inbox</h4>
                      <p className="text-sm">New emails appear instantly without manual refresh</p>
                    </div>
                  </div>
                </div>
              </div>
            </Card>
          </div>

          {/* Sidebar with Ad */}
          <div className="space-y-6">
            <AdSpace size="rectangle" />
            
            <Card className="p-6 bg-blue-50 border border-blue-200">
              <Clock className="h-8 w-8 text-blue-600 mb-4" />
              <h3 className="font-semibold text-gray-900 mb-2">Quick Tips</h3>
              <ul className="text-sm text-gray-700 space-y-2">
                <li>• Use for one-time signups</li>
                <li>• Perfect for downloading resources</li>
                <li>• Avoid using for sensitive accounts</li>
                <li>• Bookmark this page for easy access</li>
              </ul>
            </Card>
          </div>
        </div>
      </main>
    </div>
  );
};

export default HowItWorks;
