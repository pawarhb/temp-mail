
import Header from "@/components/Header";
import { Card } from "@/components/ui/card";
import { FileText, AlertTriangle, Clock, Shield } from "lucide-react";

const Terms = () => {
  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <main className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="text-center mb-8">
          <FileText className="h-12 w-12 text-blue-600 mx-auto mb-4" />
          <h1 className="text-3xl font-bold text-gray-900 mb-4">Terms of Service</h1>
          <p className="text-gray-600">Last updated: January 2025</p>
        </div>

        <div className="space-y-8">
          <Card className="p-8 bg-white">
            <div className="flex items-center space-x-3 mb-4">
              <Shield className="h-6 w-6 text-blue-600" />
              <h2 className="text-xl font-semibold text-gray-900">Service Description</h2>
            </div>
            <div className="text-gray-700 space-y-4">
              <p>
                Temp Mail Hub provides temporary email services that allow users to receive emails without using their personal email addresses. Our service includes AI-powered spam filtering and automatic email expiration.
              </p>
              <p>
                <strong>Service Features:</strong>
              </p>
              <ul className="list-disc list-inside space-y-1 ml-4">
                <li>Temporary email generation</li>
                <li>24-hour email retention</li>
                <li>AI-powered spam filtering</li>
                <li>Auto-refresh inbox functionality</li>
                <li>Mobile-responsive interface</li>
              </ul>
            </div>
          </Card>

          <Card className="p-8 bg-white">
            <div className="flex items-center space-x-3 mb-4">
              <Clock className="h-6 w-6 text-blue-600" />
              <h2 className="text-xl font-semibold text-gray-900">Usage Terms</h2>
            </div>
            <div className="text-gray-700 space-y-4">
              <p>
                <strong>Permitted Use:</strong> This service is intended for legitimate purposes such as:
              </p>
              <ul className="list-disc list-inside space-y-1 ml-4">
                <li>Account registrations and verifications</li>
                <li>Downloading resources that require email</li>
                <li>Testing email functionality</li>
                <li>Protecting personal email from spam</li>
              </ul>
              <p>
                <strong>Prohibited Activities:</strong>
              </p>
              <ul className="list-disc list-inside space-y-1 ml-4">
                <li>Illegal or fraudulent activities</li>
                <li>Spam generation or distribution</li>
                <li>Harassment or abuse of other users or services</li>
                <li>Circumventing security measures</li>
                <li>Commercial resale of our service</li>
              </ul>
            </div>
          </Card>

          <Card className="p-8 bg-white">
            <div className="flex items-center space-x-3 mb-4">
              <AlertTriangle className="h-6 w-6 text-orange-600" />
              <h2 className="text-xl font-semibold text-gray-900">Limitations & Disclaimers</h2>
            </div>
            <div className="text-gray-700 space-y-4">
              <p>
                <strong>Service Availability:</strong> We strive to maintain 99% uptime but cannot guarantee uninterrupted service. Temporary outages may occur for maintenance or technical issues.
              </p>
              <p>
                <strong>Data Retention:</strong> Emails are automatically deleted after 24 hours. We are not responsible for any data loss due to this automatic deletion policy.
              </p>
              <p>
                <strong>Third-Party Content:</strong> We are not responsible for the content of emails received through our service, including spam, malicious content, or inappropriate material.
              </p>
              <p>
                <strong>Liability Limitation:</strong> Our liability is limited to the maximum extent permitted by law. We provide this service "as is" without warranties.
              </p>
            </div>
          </Card>

          <Card className="p-8 bg-orange-50 border border-orange-200">
            <h2 className="text-xl font-semibold text-gray-900 mb-4">Important Notice</h2>
            <div className="text-gray-700 space-y-2">
              <p className="font-medium">• All emails are automatically deleted after 24 hours</p>
              <p>• Do not use this service for important or sensitive communications</p>
              <p>• We reserve the right to modify or discontinue the service at any time</p>
              <p>• Violation of these terms may result in service restriction</p>
            </div>
          </Card>

          <div className="text-center pt-8">
            <p className="text-gray-600">
              Questions about our terms? Contact us at legal@tempmailhub.com
            </p>
          </div>
        </div>
      </main>
    </div>
  );
};

export default Terms;
