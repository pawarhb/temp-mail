
import Header from "@/components/Header";
import { Card } from "@/components/ui/card";
import { Shield, Eye, Cookie, Lock } from "lucide-react";

const Privacy = () => {
  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <main className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="text-center mb-8">
          <Shield className="h-12 w-12 text-blue-600 mx-auto mb-4" />
          <h1 className="text-3xl font-bold text-gray-900 mb-4">Privacy Policy</h1>
          <p className="text-gray-600">Last updated: January 2025</p>
        </div>

        <div className="space-y-8">
          <Card className="p-8 bg-white">
            <div className="flex items-center space-x-3 mb-4">
              <Eye className="h-6 w-6 text-blue-600" />
              <h2 className="text-xl font-semibold text-gray-900">Information We Collect</h2>
            </div>
            <div className="text-gray-700 space-y-4">
              <p>
                <strong>Temporary Email Data:</strong> We temporarily store email addresses and messages for the duration of your session (maximum 24 hours). This data is automatically deleted after expiration.
              </p>
              <p>
                <strong>Usage Analytics:</strong> We collect anonymous usage statistics to improve our service, including page views, feature usage, and general location data.
              </p>
              <p>
                <strong>Cookies:</strong> We use cookies for essential functionality and, with your consent, for advertising and analytics purposes.
              </p>
            </div>
          </Card>

          <Card className="p-8 bg-white">
            <div className="flex items-center space-x-3 mb-4">
              <Lock className="h-6 w-6 text-blue-600" />
              <h2 className="text-xl font-semibold text-gray-900">How We Protect Your Data</h2>
            </div>
            <div className="text-gray-700 space-y-4">
              <p>
                <strong>Automatic Deletion:</strong> All temporary emails and their contents are automatically deleted after 24 hours.
              </p>
              <p>
                <strong>No Personal Information:</strong> We do not require or store personal information like names, addresses, or phone numbers.
              </p>
              <p>
                <strong>Encryption:</strong> All data transmission is encrypted using industry-standard SSL/TLS protocols.
              </p>
              <p>
                <strong>AI Spam Filtering:</strong> Our AI systems analyze emails for spam detection but do not store or share email content.
              </p>
            </div>
          </Card>

          <Card className="p-8 bg-white">
            <div className="flex items-center space-x-3 mb-4">
              <Cookie className="h-6 w-6 text-blue-600" />
              <h2 className="text-xl font-semibold text-gray-900">Advertising & Third Parties</h2>
            </div>
            <div className="text-gray-700 space-y-4">
              <p>
                <strong>Google AdSense:</strong> We use Google AdSense to display relevant advertisements. Google may use cookies to serve ads based on your interests.
              </p>
              <p>
                <strong>Analytics:</strong> We use analytics services to understand how our service is used and to improve user experience.
              </p>
              <p>
                <strong>No Data Selling:</strong> We never sell, rent, or share your personal data with third parties for marketing purposes.
              </p>
            </div>
          </Card>

          <Card className="p-8 bg-blue-50 border border-blue-200">
            <h2 className="text-xl font-semibold text-gray-900 mb-4">Your Rights</h2>
            <div className="text-gray-700 space-y-2">
              <p>• Right to data deletion (automatic after 24 hours)</p>
              <p>• Right to opt-out of cookies (except essential ones)</p>
              <p>• Right to contact us about privacy concerns</p>
              <p>• Right to request information about data processing</p>
            </div>
          </Card>

          <div className="text-center pt-8">
            <p className="text-gray-600">
              Questions about our privacy policy? Contact us at privacy@tempmailhub.com
            </p>
          </div>
        </div>
      </main>
    </div>
  );
};

export default Privacy;
