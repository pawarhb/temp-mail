
import Header from "@/components/Header";
import { Card } from "@/components/ui/card";
import { Shield, Mail, Users, Clock, Zap, CheckCircle } from "lucide-react";

const About = () => {
  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <main className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="text-center mb-12">
          <Mail className="h-16 w-16 text-blue-600 mx-auto mb-6" />
          <h1 className="text-4xl font-bold text-gray-900 mb-4">About Exploratool Hub</h1>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Your trusted solution for disposable email addresses. Protect your privacy online with our AI-powered temporary email service.
          </p>
        </div>

        <div className="space-y-8">
          <Card className="p-8 bg-white">
            <h2 className="text-2xl font-semibold text-gray-900 mb-4">Why We Created Exploratool Hub</h2>
            <div className="text-gray-700 space-y-4">
              <p>
                In today's digital world, your email address is constantly requested for downloads, signups, newsletters, and various online services. Unfortunately, this often leads to spam, unwanted marketing emails, and potential privacy breaches.
              </p>
              <p>
                Exploratool Hub was born from a simple idea: <strong>everyone deserves email privacy without compromise</strong>. Our temporary email service provides instant, disposable email addresses that protect your real inbox from spam while maintaining your online privacy.
              </p>
              <p>
                We believe privacy should be accessible to everyone, which is why our service requires no signup, stores no personal information, and remains completely free to use.
              </p>
            </div>
          </Card>

          <Card className="p-8 bg-white">
            <h2 className="text-2xl font-semibold text-gray-900 mb-6">How Exploratool Hub Helps You</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="flex items-start space-x-4">
                <Shield className="h-8 w-8 text-blue-600 mt-1 flex-shrink-0" />
                <div>
                  <h3 className="font-semibold text-gray-900 mb-2">Protect Your Privacy</h3>
                  <p className="text-gray-600 text-sm">Keep your personal email address private and avoid unwanted marketing emails or data collection.</p>
                </div>
              </div>
              <div className="flex items-start space-x-4">
                <Zap className="h-8 w-8 text-purple-600 mt-1 flex-shrink-0" />
                <div>
                  <h3 className="font-semibold text-gray-900 mb-2">AI Spam Protection</h3>
                  <p className="text-gray-600 text-sm">Our advanced AI filters automatically detect and block spam, phishing attempts, and malicious content.</p>
                </div>
              </div>
              <div className="flex items-start space-x-4">
                <Clock className="h-8 w-8 text-orange-600 mt-1 flex-shrink-0" />
                <div>
                  <h3 className="font-semibold text-gray-900 mb-2">Automatic Cleanup</h3>
                  <p className="text-gray-600 text-sm">All temporary emails automatically expire after 24 hours, ensuring no data is stored permanently.</p>
                </div>
              </div>
              <div className="flex items-start space-x-4">
                <Users className="h-8 w-8 text-green-600 mt-1 flex-shrink-0" />
                <div>
                  <h3 className="font-semibold text-gray-900 mb-2">No Signup Required</h3>
                  <p className="text-gray-600 text-sm">Start using disposable email addresses instantly without creating an account or providing personal information.</p>
                </div>
              </div>
            </div>
          </Card>

          <Card className="p-8 bg-white">
            <h2 className="text-2xl font-semibold text-gray-900 mb-4">Perfect Use Cases</h2>
            <div className="text-gray-700 space-y-4">
              <p>
                <strong>Exploratool Hub is ideal for:</strong>
              </p>
              <ul className="grid grid-cols-1 md:grid-cols-2 gap-3 text-sm">
                <li className="flex items-center space-x-2">
                  <CheckCircle className="h-4 w-4 text-green-600 flex-shrink-0" />
                  <span>Signing up for online services and trials</span>
                </li>
                <li className="flex items-center space-x-2">
                  <CheckCircle className="h-4 w-4 text-green-600 flex-shrink-0" />
                  <span>Downloading resources that require email</span>
                </li>
                <li className="flex items-center space-x-2">
                  <CheckCircle className="h-4 w-4 text-green-600 flex-shrink-0" />
                  <span>Testing email functionality for developers</span>
                </li>
                <li className="flex items-center space-x-2">
                  <CheckCircle className="h-4 w-4 text-green-600 flex-shrink-0" />
                  <span>Avoiding spam from untrusted websites</span>
                </li>
                <li className="flex items-center space-x-2">
                  <CheckCircle className="h-4 w-4 text-green-600 flex-shrink-0" />
                  <span>One-time email verifications</span>
                </li>
                <li className="flex items-center space-x-2">
                  <CheckCircle className="h-4 w-4 text-green-600 flex-shrink-0" />
                  <span>Protecting your main inbox from clutter</span>
                </li>
              </ul>
            </div>
          </Card>

          <Card className="p-8 bg-gradient-to-r from-blue-50 to-purple-50 border border-blue-200">
            <div className="text-center">
              <h2 className="text-2xl font-semibold text-gray-900 mb-4">Our Commitment to You</h2>
              <div className="text-gray-700 space-y-4">
                <p className="text-lg">
                  We're committed to providing a reliable, secure, and user-friendly temporary email service that respects your privacy and enhances your online experience.
                </p>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-6">
                  <div className="text-center">
                    <div className="text-2xl font-bold text-blue-600">100%</div>
                    <div className="text-sm text-gray-600">Free Forever</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-green-600">24/7</div>
                    <div className="text-sm text-gray-600">Available Service</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-purple-600">0</div>
                    <div className="text-sm text-gray-600">Personal Data Stored</div>
                  </div>
                </div>
              </div>
            </div>
          </Card>

          <div className="text-center pt-8">
            <p className="text-gray-600">
              Questions about our service? Visit our <a href="/contact" className="text-blue-600 hover:underline">Contact page</a> or check our <a href="/#faq" className="text-blue-600 hover:underline">FAQ section</a>.
            </p>
          </div>
        </div>
      </main>
    </div>
  );
};

export default About;
