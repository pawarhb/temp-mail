
import Header from "@/components/Header";
import EmailGenerator from "@/components/EmailGenerator";
import EmailInbox from "@/components/EmailInbox";
import CookieConsent from "@/components/CookieConsent";
import AdSpace from "@/components/AdSpace";
import AICompanion from "@/components/AICompanion";
import FAQ from "@/components/FAQ";
import FloatingShapes from "@/components/FloatingShapes";
import { Shield, Clock, UserCheck, Zap, Star, Users, CheckCircle, Mail, Brain, Lock } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

const Index = () => {
  const scrollToGenerator = () => {
    document.getElementById('email-generator')?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-purple-900 relative overflow-hidden">
      {/* Animated 3D Background */}
      <FloatingShapes />
      
      <Header />
      
      {/* Top Banner Ad */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-4">
        <div className="hidden md:block">
          <AdSpace size="banner" className="mx-auto backdrop-blur-sm bg-white/10 border border-white/20" />
        </div>
      </div>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 relative z-10">
        {/* Hero Section with 3D Styling */}
        <div className="text-center py-20 mb-16 relative">
          {/* Glow Effect Background */}
          <div className="absolute inset-0 bg-gradient-to-r from-blue-500/20 via-purple-500/20 to-pink-500/20 blur-3xl"></div>
          
          <div className="relative z-10">
            <div className="mb-12">
              <div className="inline-flex items-center space-x-4 mb-8 bg-white/10 backdrop-blur-md px-8 py-4 rounded-full border border-white/20">
                <div className="w-16 h-16 bg-gradient-to-br from-blue-400 to-purple-600 rounded-2xl flex items-center justify-center shadow-2xl transform hover:scale-110 transition-all duration-300">
                  <Mail className="h-8 w-8 text-white" />
                </div>
                <div>
                  <h1 className="text-4xl md:text-6xl font-bold bg-gradient-to-r from-white via-blue-200 to-purple-200 bg-clip-text text-transparent">
                    Temp Mail Hub
                  </h1>
                  <p className="text-white/80 text-lg">Temporary Email Service</p>
                </div>
              </div>
              
              <h2 className="text-3xl md:text-5xl font-bold text-white mb-6 leading-tight">
                Instant Disposable Emails.<br />
                <span className="bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent">
                  Private. Free. No Signup.
                </span>
              </h2>
              
              <p className="text-xl text-white/80 mb-12 max-w-3xl mx-auto leading-relaxed">
                Generate temporary email addresses instantly with AI-powered spam protection. 
                Perfect for signups, downloads, and protecting your real inbox from unwanted emails.
              </p>
            </div>

            {/* Trust Badges with 3D Effects */}
            <div className="flex flex-wrap justify-center gap-6 mb-12">
              <div className="flex items-center space-x-3 bg-white/10 backdrop-blur-md px-6 py-4 rounded-2xl shadow-2xl border border-white/20 hover:bg-white/20 transition-all duration-300 transform hover:scale-105">
                <div className="w-12 h-12 bg-gradient-to-br from-green-400 to-emerald-600 rounded-xl flex items-center justify-center">
                  <UserCheck className="h-6 w-6 text-white" />
                </div>
                <div>
                  <span className="text-white font-semibold">No Signup Required</span>
                  <p className="text-white/60 text-sm">Start instantly</p>
                </div>
              </div>
              
              <div className="flex items-center space-x-3 bg-white/10 backdrop-blur-md px-6 py-4 rounded-2xl shadow-2xl border border-white/20 hover:bg-white/20 transition-all duration-300 transform hover:scale-105">
                <div className="w-12 h-12 bg-gradient-to-br from-blue-400 to-cyan-600 rounded-xl flex items-center justify-center">
                  <Lock className="h-6 w-6 text-white" />
                </div>
                <div>
                  <span className="text-white font-semibold">100% Privacy</span>
                  <p className="text-white/60 text-sm">Fully encrypted</p>
                </div>
              </div>
              
              <div className="flex items-center space-x-3 bg-white/10 backdrop-blur-md px-6 py-4 rounded-2xl shadow-2xl border border-white/20 hover:bg-white/20 transition-all duration-300 transform hover:scale-105">
                <div className="w-12 h-12 bg-gradient-to-br from-purple-400 to-pink-600 rounded-xl flex items-center justify-center">
                  <Brain className="h-6 w-6 text-white" />
                </div>
                <div>
                  <span className="text-white font-semibold">AI Spam Filter</span>
                  <p className="text-white/60 text-sm">Smart protection</p>
                </div>
              </div>
            </div>

            {/* Hero CTA Button */}
            <Button 
              onClick={scrollToGenerator}
              size="lg"
              className="h-16 px-12 text-xl font-bold bg-gradient-to-r from-blue-500 via-purple-500 to-pink-500 hover:from-blue-600 hover:via-purple-600 hover:to-pink-600 text-white border-none rounded-2xl shadow-2xl hover:shadow-3xl transition-all duration-300 transform hover:scale-105 hover:-translate-y-1"
            >
              <Zap className="h-6 w-6 mr-3" />
              Generate Temporary Email
            </Button>

            {/* Stats with Glow Effects */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-2xl mx-auto mt-16">
              <div className="text-center bg-white/5 backdrop-blur-md rounded-2xl p-6 border border-white/10">
                <div className="text-4xl font-bold bg-gradient-to-r from-blue-400 to-cyan-400 bg-clip-text text-transparent">10,000+</div>
                <div className="text-white/70 text-sm">Emails Served Daily</div>
              </div>
              <div className="text-center bg-white/5 backdrop-blur-md rounded-2xl p-6 border border-white/10">
                <div className="text-4xl font-bold bg-gradient-to-r from-green-400 to-emerald-400 bg-clip-text text-transparent">99.9%</div>
                <div className="text-white/70 text-sm">Spam Blocked</div>
              </div>
              <div className="text-center bg-white/5 backdrop-blur-md rounded-2xl p-6 border border-white/10">
                <div className="text-4xl font-bold bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent">50k+</div>
                <div className="text-white/70 text-sm">Happy Users</div>
              </div>
            </div>
          </div>
        </div>

        {/* Main Content Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-3 space-y-12">
            <div id="email-generator">
              <EmailGenerator />
            </div>
            
            {/* In-content Responsive Ad with 3D styling */}
            <div className="transform hover:scale-[1.02] transition-all duration-300">
              <AdSpace size="rectangle" className="mx-auto backdrop-blur-md bg-white/10 border border-white/20 shadow-2xl" />
            </div>
            
            <EmailInbox />

            {/* Testimonials Section with 3D Cards */}
            <Card className="p-8 bg-white/10 backdrop-blur-md border border-white/20 shadow-2xl rounded-3xl">
              <h3 className="text-3xl font-bold text-center text-white mb-8">What Our Users Say</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="bg-white/10 backdrop-blur-md p-6 rounded-2xl shadow-xl border border-white/20 hover:bg-white/20 transition-all duration-300 transform hover:scale-105">
                  <div className="flex items-center mb-4">
                    {[...Array(5)].map((_, i) => (
                      <Star key={i} className="h-4 w-4 text-yellow-400 fill-current" />
                    ))}
                  </div>
                  <p className="text-white mb-4">"Perfect for signing up to services without spam. The AI filtering actually works!"</p>
                  <p className="text-sm text-white/70">- Sarah M., Developer</p>
                </div>
                <div className="bg-white/10 backdrop-blur-md p-6 rounded-2xl shadow-xl border border-white/20 hover:bg-white/20 transition-all duration-300 transform hover:scale-105">
                  <div className="flex items-center mb-4">
                    {[...Array(5)].map((_, i) => (
                      <Star key={i} className="h-4 w-4 text-yellow-400 fill-current" />
                    ))}
                  </div>
                  <p className="text-white mb-4">"Simple, fast, and reliable. Exactly what I needed for temporary registrations."</p>
                  <p className="text-sm text-white/70">- Mike R., Marketing Manager</p>
                </div>
              </div>
            </Card>
          </div>

          {/* Sidebar with 3D Effects */}
          <div className="lg:col-span-1 space-y-6">
            {/* Sidebar Ad with glow effect */}
            <div className="sticky top-6 transform hover:scale-[1.02] transition-all duration-300">
              <AdSpace size="sidebar" className="backdrop-blur-md bg-white/10 border border-white/20 shadow-2xl" />
            </div>
            
            {/* Features Highlight with 3D styling */}
            <Card className="p-6 bg-white/10 backdrop-blur-md border border-white/20 shadow-2xl rounded-2xl">
              <h3 className="font-bold text-white mb-4 flex items-center">
                <CheckCircle className="h-5 w-5 text-green-400 mr-2" />
                Key Features
              </h3>
              <ul className="space-y-3 text-sm text-white/80">
                <li className="flex items-center">
                  <span className="w-2 h-2 bg-gradient-to-r from-blue-400 to-purple-400 rounded-full mr-3"></span>
                  Instant email generation
                </li>
                <li className="flex items-center">
                  <span className="w-2 h-2 bg-gradient-to-r from-blue-400 to-purple-400 rounded-full mr-3"></span>
                  24-hour auto-deletion
                </li>
                <li className="flex items-center">
                  <span className="w-2 h-2 bg-gradient-to-r from-blue-400 to-purple-400 rounded-full mr-3"></span>
                  AI-powered spam protection
                </li>
                <li className="flex items-center">
                  <span className="w-2 h-2 bg-gradient-to-r from-blue-400 to-purple-400 rounded-full mr-3"></span>
                  No registration required
                </li>
                <li className="flex items-center">
                  <span className="w-2 h-2 bg-gradient-to-r from-blue-400 to-purple-400 rounded-full mr-3"></span>
                  Mobile-optimized design
                </li>
                <li className="flex items-center">
                  <span className="w-2 h-2 bg-gradient-to-r from-blue-400 to-purple-400 rounded-full mr-3"></span>
                  GDPR compliant
                </li>
              </ul>
            </Card>

            {/* Security Notice with glow */}
            <Card className="p-4 bg-gradient-to-br from-green-500/20 to-blue-500/20 backdrop-blur-md border border-green-400/30 shadow-2xl rounded-2xl">
              <div className="flex items-center space-x-2 mb-2">
                <Shield className="h-5 w-5 text-green-400" />
                <h4 className="font-semibold text-green-200">Security First</h4>
              </div>
              <p className="text-sm text-green-100">
                All emails are encrypted and automatically deleted. We never store personal information or track users.
              </p>
            </Card>
          </div>
        </div>

        {/* FAQ Section */}
        <div className="mt-16" id="faq">
          <FAQ />
        </div>
      </main>

      <CookieConsent />
      <AICompanion />
    </div>
  );
};

export default Index;
