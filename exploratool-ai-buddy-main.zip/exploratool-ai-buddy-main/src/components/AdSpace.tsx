
import { Card } from "@/components/ui/card";

interface AdSpaceProps {
  size: "banner" | "rectangle" | "sidebar" | "mobile";
  className?: string;
}

const AdSpace = ({ size, className = "" }: AdSpaceProps) => {
  const getAdDimensions = () => {
    switch (size) {
      case "banner":
        return { width: "728x90", height: "h-[90px]", label: "Leaderboard Banner" };
      case "rectangle":
        return { width: "300x250", height: "h-[250px]", label: "Medium Rectangle" };
      case "sidebar":
        return { width: "160x600", height: "h-[600px]", label: "Wide Skyscraper" };
      case "mobile":
        return { width: "320x50", height: "h-[50px]", label: "Mobile Banner" };
      default:
        return { width: "300x250", height: "h-[250px]", label: "Standard Ad" };
    }
  };

  const { width, height, label } = getAdDimensions();

  return (
    <div className="relative">
      <div className="absolute top-1 left-1 z-10">
        <span className="text-xs text-gray-400 bg-white px-1 rounded">Ad</span>
      </div>
      <Card className={`bg-gray-50 border-dashed border-gray-300 flex items-center justify-center ${height} ${className}`}>
        <div className="text-center text-gray-500">
          <div className="text-sm font-medium">{label}</div>
          <div className="text-xs">{width}</div>
          <div className="text-xs mt-1 text-gray-400">Advertisement</div>
        </div>
      </Card>
    </div>
  );
};

export default AdSpace;
