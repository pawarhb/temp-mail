
import { Card } from "@/components/ui/card";
import { 
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { HelpCircle } from "lucide-react";

const FAQ = () => {
  const faqs = [
    {
      question: "How long do temporary emails last?",
      answer: "All temporary emails are automatically deleted after 24 hours to protect your privacy. This ensures no data is stored permanently on our servers."
    },
    {
      question: "Is the service really free?",
      answer: "Yes, Exploratool Hub is completely free to use. We support the service through privacy-compliant advertising, but all core features remain free forever."
    },
    {
      question: "How does the AI spam filtering work?",
      answer: "Our AI system analyzes incoming emails using advanced machine learning algorithms to identify and block spam, phishing attempts, and malicious content before they reach your temporary inbox."
    },
    {
      question: "Can I use this for important accounts?",
      answer: "We recommend using temporary emails only for short-term needs like downloads, trial signups, or one-time verifications. For important accounts, use your permanent email address."
    },
    {
      question: "Do you store any personal information?",
      answer: "No, we don't store any personal information. We don't require registration, and all emails are automatically deleted after 24 hours. We're fully GDPR compliant."
    },
    {
      question: "Can I generate multiple emails?",
      answer: "Yes, you can generate as many temporary emails as you need. Each email operates independently and expires after 24 hours from creation."
    },
    {
      question: "What if I don't receive emails?",
      answer: "Try refreshing your inbox or generating a new email address. Some services may block temporary email domains, in which case you'll need to use a permanent email address."
    },
    {
      question: "Is this service secure?",
      answer: "Yes, all communications are encrypted with SSL/TLS, and we follow industry-standard security practices. However, don't use temporary emails for sensitive information."
    }
  ];

  return (
    <div className="animate-fade-in">
      <Card className="p-8 bg-white border border-gray-200 shadow-xl rounded-2xl">
        <div className="text-center mb-8">
          <div className="inline-flex items-center space-x-3 mb-4">
            <div className="w-12 h-12 bg-gradient-to-br from-purple-500 to-pink-600 rounded-xl flex items-center justify-center">
              <HelpCircle className="h-6 w-6 text-white" />
            </div>
            <h2 className="text-3xl font-bold text-gray-900">Frequently Asked Questions</h2>
          </div>
          <p className="text-gray-600 text-lg">Everything you need to know about our temporary email service</p>
        </div>

        <Accordion type="single" collapsible className="w-full max-w-4xl mx-auto">
          {faqs.map((faq, index) => (
            <AccordionItem key={index} value={`item-${index}`} className="border-b border-gray-200">
              <AccordionTrigger className="text-left hover:text-blue-600 font-semibold py-4">
                {faq.question}
              </AccordionTrigger>
              <AccordionContent className="text-gray-600 pb-4 leading-relaxed">
                {faq.answer}
              </AccordionContent>
            </AccordionItem>
          ))}
        </Accordion>
      </Card>
    </div>
  );
};

export default FAQ;
