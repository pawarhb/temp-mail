
import { useState, useEffect } from "react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Mail, Trash2, Shield, Clock, AlertCircle, RefreshCw } from "lucide-react";
import { toast } from "sonner";

interface Email {
  id: string;
  from: string;
  subject: string;
  preview: string;
  time: string;
  isSpam: boolean;
  isRead: boolean;
}

const EmailInbox = () => {
  const [emails, setEmails] = useState<Email[]>([]);
  const [selectedEmail, setSelectedEmail] = useState<Email | null>(null);
  const [isRefreshing, setIsRefreshing] = useState(false);

  // Auto-refresh functionality
  useEffect(() => {
    const interval = setInterval(() => {
      if (emails.length > 0) {
        setIsRefreshing(true);
        setTimeout(() => {
          setIsRefreshing(false);
          // Simulate checking for new emails
          const hasNewEmails = Math.random() > 0.7;
          if (hasNewEmails) {
            toast.info("📬 Checking for new emails...", {
              description: "AI is monitoring your inbox automatically."
            });
          }
        }, 1000);
      }
    }, 30000); // Check every 30 seconds

    return () => clearInterval(interval);
  }, [emails]);

  // Simulate receiving emails
  useEffect(() => {
    const timer = setTimeout(() => {
      const mockEmails: Email[] = [
        {
          id: "1",
          from: "welcome@example.com",
          subject: "Welcome! Please verify your account",
          preview: "Thank you for signing up. Click the link below to verify...",
          time: "2 min ago",
          isSpam: false,
          isRead: false,
        },
        {
          id: "2",
          from: "suspicious@fake.domain",
          subject: "🎉 CONGRATULATIONS! You've won $1,000,000!!!",
          preview: "Act now! Limited time offer. Click here to claim...",
          time: "5 min ago",
          isSpam: true,
          isRead: false,
        },
        {
          id: "3",
          from: "newsletter@techblog.com",
          subject: "Weekly Tech Newsletter - AI Advances",
          preview: "This week: Latest developments in artificial intelligence...",
          time: "1 hour ago",
          isSpam: false,
          isRead: true,
        },
      ];
      
      setEmails(mockEmails);
      
      toast.success("📧 New emails received!", {
        description: "AI has filtered 1 spam email. Your inbox is clean!"
      });
    }, 3000);

    return () => clearTimeout(timer);
  }, []);

  const deleteEmail = (emailId: string) => {
    setEmails(emails.filter(email => email.id !== emailId));
    setSelectedEmail(null);
    toast.success("🗑️ Email deleted successfully");
  };

  const markAsRead = (email: Email) => {
    setEmails(emails.map(e => 
      e.id === email.id ? { ...e, isRead: true } : e
    ));
    setSelectedEmail({ ...email, isRead: true });
  };

  const refreshInbox = () => {
    setIsRefreshing(true);
    setTimeout(() => {
      setIsRefreshing(false);
      toast.info("✅ Inbox refreshed", {
        description: "Checked for new emails - you're up to date!"
      });
    }, 1000);
  };

  const validEmails = emails.filter(email => !email.isSpam);
  const spamCount = emails.filter(email => email.isSpam).length;

  return (
    <div className="space-y-6">
      {/* Inbox Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div className="flex items-center space-x-3">
          <Mail className="h-6 w-6 text-blue-600" />
          <h2 className="text-2xl font-bold text-gray-900">Your Inbox</h2>
          <Badge variant="secondary" className="bg-blue-100 text-blue-800">
            {validEmails.length} emails
          </Badge>
        </div>
        <Button
          onClick={refreshInbox}
          disabled={isRefreshing}
          variant="outline"
          className="border-blue-600 text-blue-600 hover:bg-blue-50"
        >
          <RefreshCw className={`h-4 w-4 mr-2 ${isRefreshing ? 'animate-spin' : ''}`} />
          Refresh
        </Button>
      </div>

      {/* Main Content Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Sidebar Ad Space */}
        <div className="lg:col-span-1 space-y-6">
          <Card className="p-4 bg-gray-50 border-dashed border-gray-300">
            <div className="text-center text-gray-500 text-sm">
              Advertisement Space<br />300x250 Medium Rectangle
            </div>
            <div className="h-48 bg-gray-100 rounded mt-2"></div>
          </Card>
          
          {/* AI Tips */}
          <Card className="p-4 bg-blue-50 border border-blue-200">
            <div className="flex items-center space-x-2 mb-3">
              <Shield className="h-5 w-5 text-blue-600" />
              <span className="font-semibold text-blue-900">AI Protection Active</span>
            </div>
            {spamCount > 0 && (
              <p className="text-sm text-blue-800">
                🛡️ Blocked {spamCount} spam email(s) automatically
              </p>
            )}
            <p className="text-xs text-blue-700 mt-2">
              💡 Tip: Your emails expire in 24 hours for privacy
            </p>
          </Card>
        </div>

        {/* Email List and Preview */}
        <div className="lg:col-span-2 space-y-6">
          {/* Email List */}
          <Card className="bg-white border border-gray-200">
            <div className="p-6">
              {validEmails.length === 0 ? (
                <div className="text-center py-12 text-gray-500">
                  <Mail className="h-16 w-16 mx-auto mb-4 text-gray-300" />
                  <h3 className="text-lg font-medium mb-2">No emails yet</h3>
                  <p className="text-sm">Your temporary inbox is ready to receive emails!</p>
                </div>
              ) : (
                <div className="space-y-3">
                  {validEmails.map((email) => (
                    <div
                      key={email.id}
                      onClick={() => markAsRead(email)}
                      className={`p-4 rounded-lg border cursor-pointer transition-all duration-200 hover:shadow-md ${
                        email.isRead
                          ? "bg-gray-50 border-gray-200"
                          : "bg-white border-blue-200 shadow-sm"
                      } ${selectedEmail?.id === email.id ? "ring-2 ring-blue-400" : ""}`}
                    >
                      <div className="flex items-start justify-between">
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center space-x-2 mb-1">
                            <p className={`text-sm font-medium truncate ${
                              email.isRead ? "text-gray-600" : "text-gray-900"
                            }`}>
                              {email.from}
                            </p>
                            {!email.isRead && (
                              <div className="h-2 w-2 bg-blue-500 rounded-full"></div>
                            )}
                          </div>
                          <p className={`text-sm mb-1 truncate ${
                            email.isRead ? "text-gray-500" : "text-gray-700 font-medium"
                          }`}>
                            {email.subject}
                          </p>
                          <p className="text-xs text-gray-400 truncate">{email.preview}</p>
                        </div>
                        <div className="flex items-center space-x-2 ml-2">
                          <div className="flex items-center text-xs text-gray-400">
                            <Clock className="h-3 w-3 mr-1" />
                            {email.time}
                          </div>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={(e) => {
                              e.stopPropagation();
                              deleteEmail(email.id);
                            }}
                            className="opacity-0 group-hover:opacity-100 hover:text-red-600"
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </Card>

          {/* Email Preview */}
          {selectedEmail && (
            <Card className="bg-white border border-gray-200">
              <div className="p-6">
                <div className="border-b pb-4 mb-4">
                  <div className="flex items-center justify-between mb-2">
                    <h3 className="text-lg font-semibold text-gray-900">
                      {selectedEmail.subject}
                    </h3>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => deleteEmail(selectedEmail.id)}
                      className="text-red-600 hover:text-red-700"
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                  <div className="flex items-center justify-between text-sm text-gray-600">
                    <span>From: {selectedEmail.from}</span>
                    <span>{selectedEmail.time}</span>
                  </div>
                </div>
                <div className="text-gray-700">
                  <p>{selectedEmail.preview}</p>
                  <p className="mt-4 text-sm text-gray-500 bg-gray-50 p-4 rounded">
                    [Full email content would be displayed here...]
                  </p>
                </div>
              </div>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
};

export default EmailInbox;
