
import { Mail, Sparkles, Menu, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useState } from "react";
import { Link } from "react-router-dom";

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  return (
    <header className="bg-white/10 backdrop-blur-md border-b border-white/20 sticky top-0 z-50 shadow-2xl">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-18">
          <Link to="/" className="flex items-center space-x-3 group">
            <div className="relative">
              <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-purple-700 rounded-2xl flex items-center justify-center group-hover:scale-110 transition-transform duration-300 shadow-2xl">
                <Mail className="h-7 w-7 text-white" />
              </div>
              <Sparkles className="h-4 w-4 text-blue-400 absolute -top-1 -right-1 animate-pulse" />
            </div>
            <div>
              <h1 className="text-2xl font-bold bg-gradient-to-r from-white to-blue-200 bg-clip-text text-transparent">
                Temp Mail Hub
              </h1>
              <p className="text-xs text-white/70 hidden sm:block">Temporary Email Service</p>
            </div>
          </Link>
          
          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-2">
            <Link to="/" className="px-4 py-2 text-white/80 hover:text-white hover:bg-white/10 rounded-xl font-medium transition-all duration-200 backdrop-blur-sm">
              Home
            </Link>
            <Link to="/how-it-works" className="px-4 py-2 text-white/80 hover:text-white hover:bg-white/10 rounded-xl font-medium transition-all duration-200 backdrop-blur-sm">
              How It Works
            </Link>
            <Link to="/about" className="px-4 py-2 text-white/80 hover:text-white hover:bg-white/10 rounded-xl font-medium transition-all duration-200 backdrop-blur-sm">
              About
            </Link>
            <Link to="/privacy" className="px-4 py-2 text-white/80 hover:text-white hover:bg-white/10 rounded-xl font-medium transition-all duration-200 backdrop-blur-sm">
              Privacy
            </Link>
            <Link to="/terms" className="px-4 py-2 text-white/80 hover:text-white hover:bg-white/10 rounded-xl font-medium transition-all duration-200 backdrop-blur-sm">
              Terms
            </Link>
            <Link to="/contact" className="px-4 py-2 text-white/80 hover:text-white hover:bg-white/10 rounded-xl font-medium transition-all duration-200 backdrop-blur-sm">
              Contact
            </Link>
            <Button 
              variant="outline" 
              size="sm" 
              className="ml-4 bg-gradient-to-r from-blue-500 to-purple-600 text-white border-white/30 hover:from-blue-600 hover:to-purple-700 shadow-2xl hover:shadow-3xl transition-all duration-300 rounded-xl backdrop-blur-sm transform hover:scale-105"
            >
              Get Started
            </Button>
          </nav>

          {/* Mobile menu button */}
          <Button
            variant="ghost"
            size="sm"
            className="md:hidden hover:bg-white/10 text-white"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
          >
            {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </Button>
        </div>

        {/* Mobile Navigation */}
        {isMenuOpen && (
          <div className="md:hidden border-t border-white/20 py-4 space-y-2 bg-white/10 backdrop-blur-md rounded-b-2xl">
            <Link to="/" className="block px-4 py-3 text-white/80 hover:bg-white/10 hover:text-white rounded-xl transition-all duration-200">
              Home
            </Link>
            <Link to="/how-it-works" className="block px-4 py-3 text-white/80 hover:bg-white/10 hover:text-white rounded-xl transition-all duration-200">
              How It Works
            </Link>
            <Link to="/about" className="block px-4 py-3 text-white/80 hover:bg-white/10 hover:text-white rounded-xl transition-all duration-200">
              About
            </Link>
            <Link to="/privacy" className="block px-4 py-3 text-white/80 hover:bg-white/10 hover:text-white rounded-xl transition-all duration-200">
              Privacy
            </Link>
            <Link to="/terms" className="block px-4 py-3 text-white/80 hover:bg-white/10 hover:text-white rounded-xl transition-all duration-200">
              Terms
            </Link>
            <Link to="/contact" className="block px-4 py-3 text-white/80 hover:bg-white/10 hover:text-white rounded-xl transition-all duration-200">
              Contact
            </Link>
            <div className="px-4 pt-2">
              <Button 
                variant="outline" 
                size="sm" 
                className="w-full bg-gradient-to-r from-blue-500 to-purple-600 text-white border-white/30 hover:from-blue-600 hover:to-purple-700 rounded-xl"
              >
                Get Started
              </Button>
            </div>
          </div>
        )}
      </div>
    </header>
  );
};

export default Header;
