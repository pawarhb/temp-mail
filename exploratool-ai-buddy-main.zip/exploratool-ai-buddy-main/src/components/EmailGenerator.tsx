
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Copy, RefreshCw, Sparkles, Shield, Clock, Zap } from "lucide-react";
import { toast } from "sonner";

const EmailGenerator = () => {
  const [currentEmail, setCurrentEmail] = useState("");
  const [isGenerating, setIsGenerating] = useState(false);
  const [customPrefix, setCustomPrefix] = useState("");

  const generateEmail = () => {
    setIsGenerating(true);
    
    setTimeout(() => {
      const prefix = customPrefix || Math.random().toString(36).substring(2, 8);
      const domains = ["tempmail.online", "quickemail.co", "smartbox.temp"];
      const domain = domains[Math.floor(Math.random() * domains.length)];
      const newEmail = `${prefix}@${domain}`;
      
      setCurrentEmail(newEmail);
      setIsGenerating(false);
      setCustomPrefix("");
      
      toast.success("✨ Your temporary email is ready!", {
        description: "AI has generated a secure email that expires in 24 hours."
      });
    }, 1200);
  };

  const copyEmail = () => {
    navigator.clipboard.writeText(currentEmail);
    toast.success("📋 Copied to clipboard!", {
      description: "Your temporary email is ready to use."
    });
  };

  return (
    <div className="space-y-8 animate-fade-in">
      {/* Main Email Generator Card with 3D styling */}
      <Card className="p-8 bg-white/10 backdrop-blur-md border border-white/20 shadow-2xl rounded-3xl overflow-hidden relative transform hover:scale-[1.02] transition-all duration-300">
        <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-blue-500 via-purple-500 to-pink-500"></div>
        
        <div className="text-center mb-8">
          <div className="inline-flex items-center space-x-3 mb-6">
            <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-purple-600 rounded-2xl flex items-center justify-center shadow-2xl transform hover:scale-110 transition-all duration-300">
              <Sparkles className="h-8 w-8 text-white" />
            </div>
            <h2 className="text-4xl font-bold text-white">Generate Email</h2>
          </div>
          <p className="text-white/80 max-w-2xl mx-auto text-lg leading-relaxed">
            Create a temporary email address instantly. Perfect for signups, downloads, or any service that requires email verification.
          </p>
        </div>

        <div className="max-w-2xl mx-auto space-y-6">
          {/* Custom Prefix Input with glow effects */}
          <div className="flex flex-col sm:flex-row gap-4">
            <Input
              value={customPrefix}
              onChange={(e) => setCustomPrefix(e.target.value)}
              placeholder="Custom prefix (optional)"
              className="flex-1 h-16 text-lg border-2 border-white/20 bg-white/10 backdrop-blur-md focus:border-blue-400 focus:ring-blue-400 rounded-2xl text-white placeholder-white/60 focus:bg-white/20 transition-all duration-300 shadow-xl"
            />
            <Button
              onClick={generateEmail}
              disabled={isGenerating}
              size="lg"
              className="h-16 px-8 bg-gradient-to-r from-blue-500 via-purple-500 to-pink-500 hover:from-blue-600 hover:via-purple-600 hover:to-pink-600 text-white font-bold rounded-2xl shadow-2xl hover:shadow-3xl transition-all duration-300 transform hover:scale-105 border-none"
            >
              {isGenerating ? (
                <>
                  <RefreshCw className="h-6 w-6 mr-2 animate-spin" />
                  Generating...
                </>
              ) : (
                <>
                  <Zap className="h-6 w-6 mr-2" />
                  Generate Email
                </>
              )}
            </Button>
          </div>

          {/* Generated Email Display with 3D effects */}
          {currentEmail && (
            <div className="relative bg-gradient-to-r from-blue-500/20 via-purple-500/20 to-pink-500/20 backdrop-blur-md border-2 border-white/30 rounded-2xl p-8 animate-scale-in shadow-2xl">
              <div className="text-center">
                <p className="text-white/90 mb-4 font-semibold text-lg">Your temporary email:</p>
                <div className="flex items-center justify-center space-x-4">
                  <code className="text-2xl font-mono text-white bg-black/30 backdrop-blur-md px-6 py-4 rounded-xl border border-white/20 select-all shadow-xl">
                    {currentEmail}
                  </code>
                  <Button
                    onClick={copyEmail}
                    size="sm"
                    variant="outline"
                    className="border-2 border-white/40 text-white hover:bg-white/20 hover:text-white transition-all duration-200 rounded-xl backdrop-blur-md shadow-lg"
                  >
                    <Copy className="h-5 w-5" />
                  </Button>
                </div>
                <p className="text-white/60 mt-4 text-sm">
                  This email will expire in 24 hours automatically
                </p>
              </div>
            </div>
          )}
        </div>
      </Card>

      {/* Features Grid with 3D cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="p-6 text-center bg-white/10 backdrop-blur-md border border-white/20 rounded-2xl shadow-2xl hover:shadow-3xl transition-all duration-300 hover:scale-105 transform hover:-translate-y-2">
          <div className="w-20 h-20 bg-gradient-to-br from-blue-500 to-blue-600 rounded-3xl flex items-center justify-center mx-auto mb-6 shadow-2xl">
            <Shield className="h-10 w-10 text-white" />
          </div>
          <h3 className="font-bold text-white mb-3 text-xl">AI Spam Protection</h3>
          <p className="text-white/70 leading-relaxed">Advanced AI filters automatically block spam and suspicious emails.</p>
        </Card>
        
        <Card className="p-6 text-center bg-white/10 backdrop-blur-md border border-white/20 rounded-2xl shadow-2xl hover:shadow-3xl transition-all duration-300 hover:scale-105 transform hover:-translate-y-2">
          <div className="w-20 h-20 bg-gradient-to-br from-green-500 to-green-600 rounded-3xl flex items-center justify-center mx-auto mb-6 shadow-2xl">
            <Clock className="h-10 w-10 text-white" />
          </div>
          <h3 className="font-bold text-white mb-3 text-xl">24-Hour Expiry</h3>
          <p className="text-white/70 leading-relaxed">Emails automatically expire after 24 hours for your privacy.</p>
        </Card>
        
        <Card className="p-6 text-center bg-white/10 backdrop-blur-md border border-white/20 rounded-2xl shadow-2xl hover:shadow-3xl transition-all duration-300 hover:scale-105 transform hover:-translate-y-2">
          <div className="w-20 h-20 bg-gradient-to-br from-purple-500 to-purple-600 rounded-3xl flex items-center justify-center mx-auto mb-6 shadow-2xl">
            <RefreshCw className="h-10 w-10 text-white" />
          </div>
          <h3 className="font-bold text-white mb-3 text-xl">Auto-Refresh</h3>
          <p className="text-white/70 leading-relaxed">Inbox automatically refreshes to show new emails instantly.</p>
        </Card>
      </div>
    </div>
  );
};

export default EmailGenerator;
