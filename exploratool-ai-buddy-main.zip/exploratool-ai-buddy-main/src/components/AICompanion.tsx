
import { useState, useEffect } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Sparkles, MessageCircle, X } from "lucide-react";

const AICompanion = () => {
  const [isVisible, setIsVisible] = useState(false);
  const [currentTip, setCurrentTip] = useState(0);

  const tips = [
    {
      icon: "💡",
      title: "Smart Tip",
      message: "Your temporary email expires in 24 hours. Perfect for one-time signups!"
    },
    {
      icon: "🛡️",
      title: "Privacy First",
      message: "I automatically filter spam and protect your real email address from being exposed."
    },
    {
      icon: "⚡",
      title: "Quick Access",
      message: "Bookmark this page! Your temporary email will stay active as long as you keep the tab open."
    },
    {
      icon: "🔄",
      title: "Pro Tip",
      message: "Need multiple emails? Generate as many as you need - I'll keep them organized for you."
    }
  ];

  useEffect(() => {
    const timer = setTimeout(() => {
      setIsVisible(true);
    }, 5000);

    return () => clearTimeout(timer);
  }, []);

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentTip((prev) => (prev + 1) % tips.length);
    }, 10000);

    return () => clearInterval(interval);
  }, []);

  if (!isVisible) return null;

  const tip = tips[currentTip];

  return (
    <div className="fixed bottom-6 right-6 z-50">
      <Card className="p-4 bg-gradient-to-br from-purple-600 to-blue-600 text-white border-0 shadow-2xl max-w-sm">
        <div className="flex items-start justify-between mb-3">
          <div className="flex items-center space-x-2">
            <Sparkles className="h-5 w-5 text-yellow-300" />
            <span className="font-semibold text-sm">AI Assistant</span>
          </div>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setIsVisible(false)}
            className="text-white/70 hover:text-white hover:bg-white/10 p-1 h-auto"
          >
            <X className="h-4 w-4" />
          </Button>
        </div>
        
        <div className="space-y-2">
          <div className="flex items-center space-x-2">
            <span className="text-xl">{tip.icon}</span>
            <span className="font-medium text-sm">{tip.title}</span>
          </div>
          <p className="text-sm text-white/90 leading-relaxed">
            {tip.message}
          </p>
        </div>

        <div className="flex justify-center mt-4">
          <div className="flex space-x-1">
            {tips.map((_, index) => (
              <div
                key={index}
                className={`h-1.5 w-1.5 rounded-full transition-all duration-300 ${
                  index === currentTip ? "bg-white" : "bg-white/30"
                }`}
              />
            ))}
          </div>
        </div>
      </Card>
    </div>
  );
};

export default AICompanion;
